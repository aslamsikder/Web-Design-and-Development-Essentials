function doAlert(){
    alert("Message sent. Thank you!");
}